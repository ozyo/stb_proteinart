
gmx editconf -f 4NPQ_BA1.pdb -o GLIC_princ.pdb -center 0 0 0 -princ <<EOF
1
EOF

gmx editconf -f GLIC_princ.pdb -o GLIC_princ_rotate.pdb -rotate 0 90 0

$VMD -dispdev text -e protein_center_to_lipids.tcl -args GLIC_princ_rotate.pdb popc_332.pdb GLIC_princ_rotate_translate

gmx pdb2gmx -f GLIC_princ_rotate_translate.pdb -o GLIC_pH70.pdb -ignh -vsite hydrogens -ter

head -4 popc_332.pdb > GLIC_pH70_popc.pdb
grep 'ATOM' GLIC_pH70.pdb >> GLIC_pH70_popc.pdb
grep 'POPC' popc_332.pdb >> GLIC_pH70_popc.pdb
echo 'END' >> GLIC_pH70_popc.pdb

gmx editconf -f GLIC_pH70_popc.pdb -o GLIC_pH70_popc_center.pdb -c -bt cubic
cp /usr/local/gromacs/share/gromacs/top/vdwradii.dat b_vdwradii.dat
sed '/; Water charge sites/ a\
POP  C     0.45 \
' b_vdwradii.dat > vdwradii.dat
gmx solvate -cp GLIC_pH70_popc_center.pdb -cs -o GLIC_pH70_popc_center_sol.pdb
rm vdwradii.dat

SOL_NR=`grep "OW" GLIC_pH70_popc_center_sol.pdb | wc | awk '{printf $1}'`
LIPID_NR=`grep "POPC" GLIC_pH70_popc_center_sol.pdb | wc | awk '{printf $1/52}'`

grep -v "Protein_chain_[B-E]" topol.top > GLIC_pH70_popc_sol.top
sed -i '' '/topol_Protein_chain_A.itp"/ a\
#include "amber99sb-ildn-berger.ff/popc.itp" \
' GLIC_pH70_popc_sol.top
sed -i '' 's/Protein_chain_A     1/Protein_chain_A     5/g' GLIC_pH70_popc_sol.top
echo 'POPC            '$LIPID_NR >> GLIC_pH70_popc_sol.top
echo 'SOL             '$SOL_NR >> GLIC_pH70_popc_sol.top
sed -i '' 's/amber99sb-ildn.ff/amber99sb-ildn-berger.ff/g' GLIC_pH70_popc_sol.top

mkdir -p g_membed
cp gmembed.mdp gmembed.dat g_membed/
cd g_membed
rm *.tpr *.pdb
touch box.mdp 
gmx grompp -f box.mdp -c ../GLIC_pH70_popc_center_sol.pdb -p ../GLIC_pH70_popc_sol.top -o b4membed.tpr
gmx trjconv -f ../GLIC_pH70_popc_center_sol.pdb -o b4membed.pdb -s b4membed -ur rect -pbc mol<<EOF
0
EOF

gmx make_ndx -f ../GLIC_pH70_popc_center_sol.pdb -o index_before_gmembed.ndx<<EOF
name 13 POPC
q
EOF

gmx grompp -f gmembed.mdp -c b4membed.pdb -o gmembed.tpr -maxwarn 1 -n index_before_gmembed -p ../GLIC_pH70_popc_sol.top -v

gmx mdrun -nt 1 -s gmembed.tpr -membed gmembed.dat -c GLIC_pH70_popc_further_solvate.pdb -mn index_before_gmembed -v <<EOF
1
13
EOF

cp /usr/local/gromacs/share/gromacs/top/vdwradii.dat b_vdwradii.dat
sed '/; Water charge sites/ a\
POP  C     0.45 \
' b_vdwradii.dat > vdwradii.dat

gmx solvate -cp GLIC_pH70_popc_further_solvate.pdb -cs -o GLIC_pH70_POPC_SOL.pdb
rm vdwradii.dat

SOL_NR2=`grep "OW" GLIC_pH70_POPC_SOL.pdb | wc | awk '{printf $1}'`
LIPID_NR2=`grep "POPC" GLIC_pH70_POPC_SOL.pdb | wc | awk '{printf $1/52}'`

cp ../GLIC_pH70_popc_sol.top GLIC_pH70_POPC_SOL.top
sed -i '' "s/$SOL_NR/$SOL_NR2/g" GLIC_pH70_POPC_SOL.top
sed -i '' "s/$LIPID_NR/$LIPID_NR2/g" GLIC_pH70_POPC_SOL.top

SYS_CHARGE=`grep qtot ../topol_Protein_chain_A.itp | tail -1 | awk '{print $11 * 5}'`

echo $SYS_CHARGE
ION_NUMBER=`echo "scale=9; (0.1 / 55.5)*$SOL_NR2" | bc `
ION_NUMBER=${ION_NUMBER%%.*}

if [ $SYS_CHARGE -gt 0 ]; then
        let NEG_ION=$ION_NUMBER+$SYS_CHARGE
        let POS_ION=$ION_NUMBER
        echo "CL- :"$NEG_ION" Na+ :"$POS_ION
elif [ $SYS_CHARGE -lt 0 ]; then
        let NEG_ION=$ION_NUMBER
        let POS_ION=$ION_NUMBER-$SYS_CHARGE
        echo "CL- :"$NEG_ION" Na+ :"$POS_ION
else
        let NEG_ION=$ION_NUMBER
        let POS_ION=$ION_NUMBER
        echo "CL- :"$NEG_ION" Na+ :"$POS_ION
fi

cd ../
cp g_membed/GLIC_pH70_POPC_SOL.top GLIC_pH70_POPC_SOL_ION.top
touch ion.mdp
gmx grompp -f ion.mdp -c g_membed/GLIC_pH70_POPC_SOL.pdb -p GLIC_pH70_POPC_SOL_ION.top -o 4ion.tpr
gmx genion -s 4ion.tpr -nn $NEG_ION -np $POS_ION -p GLIC_pH70_POPC_SOL_ION.top -o GLIC_pH70_POPC_SOL_ION.pdb<<EOF
15
EOF


echo '; Include Position restraint file
#ifdef POSRES_HEAVY
#include "posre_Protein_chain_A.itp"
#endif
                                                                                                                                                                                  
; Include Position restraint file
#ifdef POSRES_BACKBONE
#include "posre_Protein_chain_A_backbone.itp"
#endif
                                                                                                                                                                                  
; Include Position restraint file                                                                                                                                                 
#ifdef POSRES_CA
#include "posre_Protein_chain_A_ca.itp"
#endif' >> topol_Protein_chain_A.itp

gmx make_ndx -f GLIC_pH70_POPC_SOL_ION.pdb -o posre.ndx<<EOF
keep 4
0 & chain A 
0 & chain A & a CA
q
EOF

gmx genrestr -f GLIC_pH70_POPC_SOL_ION.pdb -n posre.ndx -o posre_Protein_chain_A_backbone<<EOF
1
EOF

gmx genrestr -f GLIC_pH70_POPC_SOL_ION.pdb -n posre.ndx -o posre_Protein_chain_A_ca<<EOF
2
EOF

cp *chain_A*itp ../run-files/
cp GLIC_pH70_POPC_SOL_ION.??? ../run-files/
cp -r amber99sb*.ff ../run-files/
